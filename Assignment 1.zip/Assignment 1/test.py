print(11//2)
print(int(7**(1/2)))